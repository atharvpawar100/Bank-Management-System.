// 3. Account.cpp - ABSTRACT base class (abstraction, encapsulation, static members)
#pragma once
#include "Exceptions.cpp"
#include "Transaction.cpp"
#include <vector>

class Account {
protected:
    int accNo;
    double balance;
    std::vector<Transaction> history;
    static int nextAccNo;       // static: auto-generates account numbers
    static int totalAccounts;   // static: counts live objects

    void record(const std::string& type, double amt) {
        history.emplace_back(type, amt, balance);
    }
public:
    explicit Account(double initial) : accNo(nextAccNo++), balance(initial) {
        totalAccounts++;
        record("Opening Balance", initial);
    }
    virtual ~Account() { totalAccounts--; }

    virtual void deposit(double amt) {
        if (amt <= 0) throw InvalidAmountException();
        balance += amt;
        record("Deposit", amt);
    }

    // Pure virtual functions => Account cannot be instantiated
    virtual void withdraw(double amt) = 0;
    virtual double monthlyUpdate() = 0;           // interest (+) or fee (-)
    virtual std::string type() const = 0;

    virtual void display() const {
        std::cout << "[" << type() << "] A/C " << accNo
                  << " | Balance: " << std::fixed << std::setprecision(2) << balance << "\n";
    }
    void printStatement() const {
        std::cout << "--- Statement: A/C " << accNo << " (" << type() << ") ---\n";
        for (const auto& t : history) std::cout << t << "\n";
    }

    Account& operator+=(double amt) { deposit(amt); return *this; }  // operator overloading

    // ---- support for file loading ----
    void restoreState(int no, double bal) { accNo = no; balance = bal; history.clear(); }
    void addHistory(const Transaction& t) { history.push_back(t); }
    const std::vector<Transaction>& getHistory() const { return history; }
    static void setNextAccNo(int n) { nextAccNo = n; }
    static int getNextAccNo() { return nextAccNo; }

    int getAccNo() const { return accNo; }
    double getBalance() const { return balance; }
    static int getTotalAccounts() { return totalAccounts; }
};
int Account::nextAccNo = 1001;
int Account::totalAccounts = 0;
