// 2. Transaction.cpp - one record of money movement (friend + operator<<)
#pragma once
#include <iostream>
#include <iomanip>
#include <string>
#include <ctime>

class Transaction {
    std::string type;
    double amount;
    double balanceAfter;
    std::string time;
public:
    Transaction(const std::string& t, double a, double b)
        : type(t), amount(a), balanceAfter(b) {
        std::time_t now = std::time(nullptr);
        char buf[20];
        std::strftime(buf, sizeof(buf), "%d-%m-%Y %H:%M", std::localtime(&now));
        time = buf;
    }
    // used when loading from file (keeps the original timestamp)
    Transaction(const std::string& t, double a, double b, const std::string& tm)
        : type(t), amount(a), balanceAfter(b), time(tm) {}

    const std::string& getType() const { return type; }
    double getAmount() const { return amount; }
    double getBalanceAfter() const { return balanceAfter; }
    const std::string& getTime() const { return time; }

    friend std::ostream& operator<<(std::ostream& os, const Transaction& t) {
        os << std::left << std::setw(18) << t.time << std::setw(18) << t.type
           << std::right << std::setw(10) << std::fixed << std::setprecision(2) << t.amount
           << "  Bal: " << t.balanceAfter;
        return os;
    }
};
