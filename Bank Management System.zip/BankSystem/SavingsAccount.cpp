// 4. SavingsAccount.cpp - derived class #1 (inheritance + polymorphism)
#pragma once
#include "Account.cpp"

class SavingsAccount : public Account {
    static constexpr double MIN_BALANCE = 500.0;
    static constexpr double RATE = 0.04;   // 4% yearly
public:
    explicit SavingsAccount(double initial) : Account(initial) {}

    void withdraw(double amt) override {
        if (amt <= 0) throw InvalidAmountException();
        if (balance - amt < MIN_BALANCE) throw InsufficientFundsException();
        balance -= amt;
        record("Withdraw", amt);
    }
    double monthlyUpdate() override {          // adds interest
        double interest = balance * RATE / 12;
        balance += interest;
        record("Interest", interest);
        return interest;
    }
    std::string type() const override { return "Savings"; }
};
