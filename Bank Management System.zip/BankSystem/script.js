/* =====================================================================
   Indian Bank (blue) + National Bank (red)
   JavaScript port of the C++ project - same classes, rules and messages.
   ===================================================================== */

/* ---------- Exceptions.cpp ---------- */
class BankException extends Error {}
class InsufficientFundsException extends BankException {
  constructor(){ super("Insufficient funds / limit exceeded!"); }
}
class InvalidAmountException extends BankException {
  constructor(){ super("Amount must be greater than zero!"); }
}
class NotFoundException extends BankException {
  constructor(what){ super(what + " not found!"); }
}

/* ---------- Transaction.cpp ---------- */
function nowStamp(){
  const d = new Date(), p = n => String(n).padStart(2, "0");
  return `${p(d.getDate())}-${p(d.getMonth()+1)}-${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
class Transaction {
  constructor(type, amount, balanceAfter, time){
    this.type = type; this.amount = amount; this.balanceAfter = balanceAfter;
    this.time = time || nowStamp();
  }
}

/* ---------- Account.cpp (abstract) ---------- */
class Account {
  constructor(accNo, initial){
    if (new.target === Account) throw new TypeError("Account is abstract");
    this.accNo = accNo;
    this.balance = initial;
    this.history = [];
    this.record("Opening Balance", initial);
  }
  record(type, amt){ this.history.push(new Transaction(type, amt, this.balance)); }
  deposit(amt){
    if (!(amt > 0)) throw new InvalidAmountException();
    this.balance += amt;
    this.record("Deposit", amt);
  }
  restoreState(no, bal){ this.accNo = no; this.balance = bal; this.history = []; }
  addHistory(t){ this.history.push(t); }
}

/* ---------- SavingsAccount.cpp ---------- */
class SavingsAccount extends Account {
  static MIN_BALANCE = 500.0;
  static RATE = 0.04;
  withdraw(amt){
    if (!(amt > 0)) throw new InvalidAmountException();
    if (this.balance - amt < SavingsAccount.MIN_BALANCE) throw new InsufficientFundsException();
    this.balance -= amt;
    this.record("Withdraw", amt);
  }
  monthlyUpdate(){
    const interest = this.balance * SavingsAccount.RATE / 12;
    this.balance += interest;
    this.record("Interest", interest);
    return interest;
  }
  monthlyPreview(){ return this.balance * SavingsAccount.RATE / 12; }
  type(){ return "Savings"; }
}

/* ---------- CurrentAccount.cpp ---------- */
class CurrentAccount extends Account {
  static OVERDRAFT = 5000.0;
  static FEE = 100.0;
  withdraw(amt){
    if (!(amt > 0)) throw new InvalidAmountException();
    if (this.balance - amt < -CurrentAccount.OVERDRAFT) throw new InsufficientFundsException();
    this.balance -= amt;
    this.record("Withdraw", amt);
  }
  monthlyUpdate(){
    this.balance -= CurrentAccount.FEE;
    this.record("Maintenance Fee", CurrentAccount.FEE);
    return -CurrentAccount.FEE;
  }
  monthlyPreview(){ return -CurrentAccount.FEE; }
  type(){ return "Current"; }
}

/* ---------- Customer.cpp ---------- */
class Customer {
  constructor(id, name){ this.id = id; this.name = name; this.accounts = []; }
  openAccount(kind, initial, accNo){
    const acc = (kind === "s" || kind === "S") ? new SavingsAccount(accNo, initial) : new CurrentAccount(accNo, initial);
    this.accounts.push(acc);
    return acc;
  }
  findAccount(no){ return this.accounts.find(a => a.accNo === no) || null; }
  removeAccount(no){                      // returns {acc, index} or null
    const i = this.accounts.findIndex(a => a.accNo === no);
    if (i < 0) return null;
    return { acc: this.accounts.splice(i, 1)[0], index: i };
  }
  removeAccountsByType(t){                // returns [{acc, index}, ...]
    const removed = [];
    this.accounts.forEach((a, i) => { if (a.type() === t) removed.push({ acc: a, index: i }); });
    this.accounts = this.accounts.filter(a => a.type() !== t);
    return removed;
  }
  totalBalance(){ return this.accounts.reduce((s, a) => s + a.balance, 0); }
}

/* ---------- Bank.cpp (each bank keeps its own customers + numbering) ---------- */
class Bank {
  constructor(cfg){
    this.cfg = cfg; this.name = cfg.name;
    this.handle = null;                 // linked real txt file (Chrome / Edge)
    this.reset();
  }
  reset(){ this.customers = []; this.nextCustId = 1; this.nextAccNo = this.cfg.firstAcc; }

  load(text){                           // parse into a temp bank first, so a bad file changes nothing
    const tmp = new Bank(this.cfg);
    parseInto(text, tmp);
    this.customers = tmp.customers; this.nextCustId = tmp.nextCustId; this.nextAccNo = tmp.nextAccNo;
  }

  addCustomer(name){ const c = new Customer(this.nextCustId++, name); this.customers.push(c); return c; }
  restoreCustomer(id, name){ const c = new Customer(id, name); this.customers.push(c); return c; }
  openAccount(cust, kind, initial){ return cust.openAccount(kind, initial, this.nextAccNo++); }

  getCustomer(id){
    const c = this.customers.find(c => c.id === id);
    if (!c) throw new NotFoundException("Customer");
    return c;
  }
  findAccount(no){
    for (const c of this.customers){ const a = c.findAccount(no); if (a) return a; }
    throw new NotFoundException("Account");
  }
  deleteAccount(no){
    for (const c of this.customers){
      const r = c.removeAccount(no);
      if (r) return { kind: "account", customer: c, removed: [r] };
    }
    throw new NotFoundException("Account");
  }
  deleteAccountsByType(custId, type){
    const c = this.getCustomer(custId);
    const removed = c.removeAccountsByType(type);
    if (removed.length === 0) throw new BankException("This customer has no " + type + " account!");
    return { kind: "accounts", customer: c, removed };
  }
  deleteCustomer(id){
    const i = this.customers.findIndex(c => c.id === id);
    if (i < 0) throw new NotFoundException("Customer");
    return { kind: "customer", customer: this.customers.splice(i, 1)[0], index: i };
  }
  undoDelete(rec){                        // puts back what a delete removed
    if (rec.kind === "customer") this.customers.splice(rec.index, 0, rec.customer);
    else for (const r of rec.removed) rec.customer.accounts.splice(r.index, 0, r.acc);
  }
  transfer(from, to, amt){
    const src = this.findAccount(from), dst = this.findAccount(to);
    src.withdraw(amt);     // throws first, so deposit never runs
    src.history[src.history.length - 1].type = "Sent to A/C " + to;
    dst.deposit(amt);
    dst.history[dst.history.length - 1].type = "Received from A/C " + from;
  }
  previewMonthlyUpdate(){                 // what Monthly Update WOULD do (changes nothing)
    const rows = [];
    for (const c of this.customers)
      for (const a of c.accounts)
        rows.push({ accNo: a.accNo, customer: c.name, type: a.type(), balance: a.balance, change: a.monthlyPreview() });
    return rows;
  }
  applyMonthlyUpdate(){
    const lines = [];
    for (const c of this.customers)
      for (const a of c.accounts){
        const r = a.monthlyUpdate();
        lines.push({ accNo: a.accNo, type: a.type(), amount: r });
      }
    return lines;
  }
  accountCount(){ return this.customers.reduce((s, c) => s + c.accounts.length, 0); }
  totalDeposits(){ return this.customers.reduce((s, c) => s + c.totalBalance(), 0); }
}

/* ---------- Transfer to the other bank ---------- */
function interBankTransfer(srcBank, fromNo, dstBank, toNo, amt){
  const a = srcBank.findAccount(fromNo);
  let b;
  try { b = dstBank.findAccount(toNo); }
  catch (e){ throw new BankException("Account not found in " + dstBank.name + "!"); }
  a.withdraw(amt);                                   // throws first, so deposit never runs
  a.history[a.history.length - 1].type = "Sent to " + dstBank.name;
  b.deposit(amt);
  b.history[b.history.length - 1].type = "Received from " + srcBank.name;
}

/* ---------- FileManager.cpp : same txt format as the C++ program ---------- */
const clean = s => s.replace(/[|\r\n]/g, "_");

function serialize(bank){
  let out = `# ${bank.name} data file - edit with care\n`;
  out += `NEXT_CUSTOMER_ID|${bank.nextCustId}\n`;
  out += `NEXT_ACCOUNT_NO|${bank.nextAccNo}\n`;
  for (const c of bank.customers){
    out += `CUSTOMER|${c.id}|${clean(c.name)}\n`;
    for (const a of c.accounts){
      out += `ACCOUNT|${a.accNo}|${a.type() === "Savings" ? "S" : "C"}|${a.balance.toFixed(2)}\n`;
      for (const t of a.history)
        out += `TXN|${t.time}|${t.type}|${t.amount.toFixed(2)}|${t.balanceAfter.toFixed(2)}\n`;
    }
  }
  return out;
}

function parseInto(text, bank){
  let cust = null, acc = null, line = "";
  let nextCust = 1, nextAcc = bank.cfg.firstAcc, maxCust = 0, maxAcc = bank.cfg.firstAcc - 1;
  try {
    for (line of text.split(/\r?\n/)){
      if (line === "" || line[0] === "#") continue;
      const f = line.split("|");
      const bad = () => { throw new Error("bad"); };
      const num = v => { const n = Number(v); if (v === undefined || v === "" || isNaN(n)) bad(); return n; };
      switch (f[0]){
        case "NEXT_CUSTOMER_ID": nextCust = num(f[1]); break;
        case "NEXT_ACCOUNT_NO":  nextAcc  = num(f[1]); break;
        case "CUSTOMER": {
          const id = num(f[1]); if (f[2] === undefined) bad();
          cust = bank.restoreCustomer(id, f[2]); acc = null; maxCust = Math.max(maxCust, id); break;
        }
        case "ACCOUNT": {
          if (!cust) throw new BankException("ACCOUNT before CUSTOMER");
          const no = num(f[1]); if (!f[2]) bad();
          acc = cust.openAccount(f[2][0], 0, no);
          acc.restoreState(no, num(f[3]));
          maxAcc = Math.max(maxAcc, no); break;
        }
        case "TXN":
          if (!acc) throw new BankException("TXN before ACCOUNT");
          acc.addHistory(new Transaction(f[2], num(f[3]), num(f[4]), f[1])); break;
      }
    }
  } catch (e){
    if (e instanceof BankException) throw e;
    throw new BankException(`Data file '${bank.cfg.key}' is corrupted (bad line: ${line})`);
  }
  bank.nextCustId = Math.max(nextCust, maxCust + 1);
  bank.nextAccNo  = Math.max(nextAcc, maxAcc + 1);
}

async function saveBank(bank){
  const text = serialize(bank);
  try { localStorage.setItem(bank.cfg.key, text); } catch (e) {}
  if (bank.handle){
    try {
      const w = await bank.handle.createWritable();
      await w.write(text); await w.close();
    } catch (e){ throw new BankException("Cannot write to file " + bank.cfg.key); }
  }
}

function downloadBank(bank){
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([serialize(bank)], { type: "text/plain" }));
  a.download = bank.cfg.key;
  a.click();
  URL.revokeObjectURL(a.href);
}

/* ---------- starting data (same as the txt files shipped in the zip) ---------- */
const INDIAN_DEFAULT = `# Indian Bank data file - edit with care
NEXT_CUSTOMER_ID|3
NEXT_ACCOUNT_NO|1004
CUSTOMER|1|Ali
ACCOUNT|1001|S|9500.00
TXN|19-10-2026 04:10|Opening Balance|10000.00|10000.00
TXN|19-10-2026 04:10|Withdraw|1000.00|9000.00
TXN|19-10-2026 04:10|Deposit|500.00|9500.00
ACCOUNT|1003|C|300.00
TXN|19-10-2026 04:10|Opening Balance|300.00|300.00
CUSTOMER|2|Sara
ACCOUNT|1002|C|3000.00
TXN|19-10-2026 04:10|Opening Balance|2000.00|2000.00
TXN|19-10-2026 04:10|Deposit|1000.00|3000.00
`;
const NATIONAL_DEFAULT = `# National Bank data file - edit with care
NEXT_CUSTOMER_ID|3
NEXT_ACCOUNT_NO|5003
CUSTOMER|1|Ravi
ACCOUNT|5001|S|20000.00
TXN|27-10-2026 10:00|Opening Balance|20000.00|20000.00
CUSTOMER|2|Meera
ACCOUNT|5002|C|4000.00
TXN|27-10-2026 10:00|Opening Balance|4000.00|4000.00
`;

const VIT_DEFAULT = `# VIT Bank data file - edit with care
NEXT_CUSTOMER_ID|3
NEXT_ACCOUNT_NO|7003
CUSTOMER|1|Arjun
ACCOUNT|7001|S|15000.00
TXN|27-10-2026 10:00|Opening Balance|15000.00|15000.00
CUSTOMER|2|Priya
ACCOUNT|7002|C|2500.00
TXN|27-10-2026 10:00|Opening Balance|2500.00|2500.00
`;

const ROYAL_DEFAULT = `# Royal Bank data file - edit with care
NEXT_CUSTOMER_ID|3
NEXT_ACCOUNT_NO|3003
CUSTOMER|1|Karan
ACCOUNT|3001|S|25000.00
TXN|27-10-2026 10:00|Opening Balance|25000.00|25000.00
CUSTOMER|2|Neha
ACCOUNT|3002|C|6000.00
TXN|27-10-2026 10:00|Opening Balance|6000.00|6000.00
`;
const GOLDEN_DEFAULT = `# Golden Trust Bank data file - edit with care
NEXT_CUSTOMER_ID|3
NEXT_ACCOUNT_NO|4003
CUSTOMER|1|Rohit
ACCOUNT|4001|S|30000.00
TXN|27-10-2026 10:00|Opening Balance|30000.00|30000.00
CUSTOMER|2|Anita
ACCOUNT|4002|C|5000.00
TXN|27-10-2026 10:00|Opening Balance|5000.00|5000.00
`;
const TITAN_DEFAULT = `# Titan Bank data file - edit with care
NEXT_CUSTOMER_ID|3
NEXT_ACCOUNT_NO|6003
CUSTOMER|1|Dev
ACCOUNT|6001|S|40000.00
TXN|27-10-2026 10:00|Opening Balance|40000.00|40000.00
CUSTOMER|2|Isha
ACCOUNT|6002|C|8000.00
TXN|27-10-2026 10:00|Opening Balance|8000.00|8000.00
`;

/* =====================================================================
   UI (replaces ConsoleUI in main.cpp)
   ===================================================================== */
const banks = {
  indian:   new Bank({ name: "Indian Bank",       theme: "indian",   key: "bank_data.txt",              firstAcc: 1001, defaultData: INDIAN_DEFAULT }),
  national: new Bank({ name: "National Bank",     theme: "national", key: "national_bank_data.txt",     firstAcc: 5001, defaultData: NATIONAL_DEFAULT }),
  vit:      new Bank({ name: "VIT Bank",          theme: "vit",      key: "vit_bank_data.txt",          firstAcc: 7001, defaultData: VIT_DEFAULT }),
  royal:    new Bank({ name: "Royal Bank",        theme: "royal",    key: "royal_bank_data.txt",        firstAcc: 3001, defaultData: ROYAL_DEFAULT }),
  golden:   new Bank({ name: "Golden Trust Bank", theme: "golden",   key: "golden_trust_bank_data.txt", firstAcc: 4001, defaultData: GOLDEN_DEFAULT }),
  titan:    new Bank({ name: "Titan Bank",        theme: "titan",    key: "titan_bank_data.txt",        firstAcc: 6001, defaultData: TITAN_DEFAULT })
};
let cur = banks.indian;

const $ = id => document.getElementById(id);
const money = v => v.toFixed(2);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[c]));
const errText = e => (e instanceof BankException ? e.message : "Unexpected error: " + e.message);

/* ----- messages ----- */
function toast(msg, kind){
  const t = document.createElement("div");
  t.className = "toast " + kind; t.textContent = msg;
  $("toasts").appendChild(t);
  setTimeout(() => t.remove(), 3800);
}
function ok(m)  { toast(m, "ok");  return `<div class="alert ok">&#10004; ${esc(m)}</div>`; }
function err(m) { toast(m, "err"); return `<div class="alert err">&#10008; ${esc(m)}</div>`; }
function info(m){ return `<div class="alert info">${m}</div>`; }
function show(html){ $("output").innerHTML = html; }

/* ----- load saved data for all banks (same as main()) ----- */
function stored(key){ try { return localStorage.getItem(key); } catch (e){ return null; } }
for (const b of Object.values(banks)){
  try { b.load(stored(b.cfg.key) || b.cfg.defaultData); }
  catch (e){ toast(b.name + ": " + e.message, "err"); }
}

/* ----- dark / light mode (sun / moon button) ----- */
function setMode(m){
  document.body.dataset.mode = m;
  $("modeBtn").textContent = m === "dark" ? "\u2600\uFE0F" : "\uD83C\uDF19";
  $("modeBtn").title = m === "dark" ? "Switch to light mode" : "Switch to dark mode";
  try { localStorage.setItem("bank_mode", m); } catch (e) {}
}
setMode(stored("bank_mode") === "dark" ? "dark" : "light");
$("modeBtn").addEventListener("click", () => setMode(document.body.dataset.mode === "dark" ? "light" : "dark"));

/* ----- welcome animation ----- */
function welcome(){
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const w = $("welcome");
  $("welcomeName").textContent = cur.name.toUpperCase();
  w.classList.remove("show"); void w.offsetWidth; w.classList.add("show");
  clearTimeout(welcome.timer);
  welcome.timer = setTimeout(() => w.classList.remove("show"), 2200);
}

/* ----- bank colours (shown in the Switch Bank dropdown) ----- */
const PALETTE = {                      // [dark, mid, bright]
  indian:   ["#0b1b2e", "#12304f", "#3b82f6"],
  national: ["#2b0a0e", "#59151c", "#ef4444"],
  vit:      ["#06261a", "#0f5a3c", "#10b981"],
  royal:    ["#1c0b2e", "#4a1f82", "#8b5cf6"],
  golden:   ["#2a1f04", "#6b4f0a", "#e0a82e"],
  titan:    ["#050505", "#26272c", "#d1d5db"]
};
const swatch = k => `<span class="sw">${PALETTE[k].map(c => `<i style="background:${c}"></i>`).join("")}</span>`;

function updateBankMenu(){
  $("bankBtn").innerHTML = `${swatch(cur.cfg.theme)}<span class="nm">${esc(cur.name)}</span><span>&#9662;</span>`;
  $("bankList").querySelectorAll(".bank-opt").forEach(o => o.classList.toggle("active", o.dataset.bank === cur.cfg.theme));
}

/* ----- banner (theme, name, numbers) ----- */
function banner(){
  document.body.dataset.bank = cur.cfg.theme;
  document.title = cur.name;
  $("bankName").textContent = cur.name.toUpperCase();
  updateBankMenu();
  $("statCustomers").textContent = cur.customers.length;
  $("statAccounts").textContent  = cur.accountCount();
  $("statDeposits").textContent  = money(cur.totalDeposits());
  const linked = !!cur.handle;
  $("fileStatus").textContent = linked ? "Data: linked to " + cur.cfg.key : "Data: browser storage";
  $("fileStatus").className = "file-status" + (linked ? " linked" : "");
  $("linkBtn").textContent = "Link " + cur.cfg.key;
}

/* ----- input readers (readInt / readDouble) ----- */
function readInt(id){
  const s = $(id).value.trim();
  if (!/^[+-]?\d+$/.test(s)) throw new BankException("Please enter a valid whole number.");
  return parseInt(s, 10);
}
function readDouble(id){
  const s = $(id).value.trim();
  if (s === "" || isNaN(Number(s))) throw new BankException("Please enter a valid amount.");
  return Number(s);
}

/* ----- accounts table + search ----- */
function accountsTable(query = ""){
  const q = query.trim().toLowerCase();
  let rows = "", found = 0;
  for (const c of cur.customers){
    const nameHit = q && c.name.toLowerCase().includes(q);
    if (!c.accounts.length && (!q || nameHit)){
      rows += `<tr><td>${c.id}</td><td>${esc(c.name)}</td><td colspan="3" class="hint">(no accounts)</td></tr>`;
      found++;
    }
    for (const a of c.accounts){
      if (q && !nameHit && !String(a.accNo).includes(q)) continue;
      found++;
      rows += `<tr><td>${c.id}</td><td>${esc(c.name)}</td><td>${a.accNo}</td>
        <td><span class="tag ${a.type()}">${a.type()}</span></td>
        <td class="num ${a.balance < 0 ? "neg" : "pos"}">${money(a.balance)}</td></tr>`;
    }
  }
  if (!rows) return info(q ? `No results for &ldquo;${esc(query.trim())}&rdquo;.` : "No customers yet.");
  return (q ? `<div class="hint count">${found} result(s) found</div>` : "") +
    `<div class="table-wrap"><table>
    <tr><th>ID</th><th>Customer</th><th>A/C No</th><th>Type</th><th class="num">Balance</th></tr>${rows}</table></div>`;
}

/* ----- statement (with filter, print and download) ----- */
let stmt = null;                      // { bank, acc, owner, filter }
const FILTERS = [["all", "All"], ["deposit", "Deposits"], ["withdraw", "Withdrawals"], ["transfer", "Transfers"], ["other", "Interest & Fees"]];

function txnMatches(t, f){
  switch (f){
    case "deposit":  return t.type === "Deposit";
    case "withdraw": return t.type === "Withdraw";
    case "transfer": return t.type.startsWith("Sent to") || t.type.startsWith("Received from");
    case "other":    return t.type === "Interest" || t.type === "Maintenance Fee";
    default:         return true;
  }
}
const stmtRows = () => stmt.acc.history.filter(t => txnMatches(t, stmt.filter));

function statementHtml(){
  const rows = stmtRows(), a = stmt.acc;
  const pills = FILTERS.map(([k, l]) =>
    `<button type="button" class="pill${k === stmt.filter ? " active" : ""}" data-filter="${k}">${l}</button>`).join("");
  const body = rows.length
    ? `<div class="table-wrap"><table><tr><th>Date</th><th>Type</th><th class="num">Amount</th><th class="num">Balance</th></tr>` +
      rows.map(t => `<tr><td>${t.time}</td><td>${esc(t.type)}</td><td class="num">${money(t.amount)}</td><td class="num">${money(t.balanceAfter)}</td></tr>`).join("") +
      `</table></div>`
    : info("No transactions for this filter.");
  return `<div class="sub">Statement: A/C ${a.accNo} (${a.type()}) &mdash; ${esc(stmt.owner)}</div>
    <div class="toolbar">
      <div class="pills">${pills}</div>
      <div class="actions">
        <button type="button" class="tool-btn" data-print>&#128424; Print / PDF</button>
        <button type="button" class="tool-btn" data-csv>&#11015; Download</button>
      </div>
    </div>
    <div class="hint count">Showing ${rows.length} of ${a.history.length} transaction(s)</div>${body}`;
}

function printStatement(){
  const rows = stmtRows(), a = stmt.acc;
  const label = FILTERS.find(f => f[0] === stmt.filter)[1];
  $("printArea").innerHTML = `<h1>${esc(stmt.bank.name)}</h1><h2>Account Statement</h2>
    <p><b>Customer:</b> ${esc(stmt.owner)} &nbsp; <b>A/C No:</b> ${a.accNo} (${a.type()}) &nbsp; <b>Balance:</b> ${money(a.balance)}</p>
    <p><b>Showing:</b> ${label} &nbsp; <b>Printed:</b> ${nowStamp()}</p>
    <table><tr><th>Date</th><th>Type</th><th style="text-align:right">Amount</th><th style="text-align:right">Balance</th></tr>` +
    rows.map(t => `<tr><td>${t.time}</td><td>${esc(t.type)}</td><td style="text-align:right">${money(t.amount)}</td><td style="text-align:right">${money(t.balanceAfter)}</td></tr>`).join("") +
    `</table>`;
  window.print();
}

function downloadStatement(){
  const q = v => '"' + String(v).replace(/"/g, '""') + '"';
  const lines = ["Date,Type,Amount,Balance After"].concat(
    stmtRows().map(t => [t.time, t.type, money(t.amount), money(t.balanceAfter)].map(q).join(",")));
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv" }));
  a.download = `statement_${stmt.acc.accNo}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

/* ----- undo last delete ----- */
let lastDelete = null;                // { bank, rec, text }
function refreshUndoBox(){
  const box = $("undoBox");
  if (!box) return;
  box.innerHTML = lastDelete && lastDelete.bank === cur
    ? `<div class="alert info undo-row"><span>Last deleted: ${esc(lastDelete.text)}</span>
       <button type="button" class="undo-btn" data-undo>&#8630; Undo Delete</button></div>` : "";
}
async function undoDelete(){
  if (!lastDelete || lastDelete.bank !== cur){ show(err("Nothing to undo.")); return; }
  try {
    lastDelete.bank.undoDelete(lastDelete.rec);
    const text = lastDelete.text;
    lastDelete = null;
    await saveBank(cur);
    refreshUndoBox();
    show(ok("Undo successful: " + text + " restored.") + info("&#128190; Data saved to " + esc(cur.cfg.key)));
  } catch (e){ show(err(errText(e))); }
  banner();
}

/* ----- forms ----- */
const field = (id, label, type = "text", labelId = "") =>
  `<div class="field"><label for="${id}"${labelId ? ` id="${labelId}"` : ""}>${label}</label><input id="${id}" type="${type}" ${type === "number" ? 'step="any"' : ""}></div>`;

function getForm(n){
  switch (n){
    case 1: return { title: "New Customer", button: "Create Customer", html: field("f_name", "Customer name") };
    case 2: return { title: "Open Account", button: "Open Account",
      html: field("f_cid", "Customer ID", "number") +
        `<div class="field"><label for="f_kind">Type</label><select id="f_kind">
          <option value="s">Savings</option><option value="c">Current</option></select></div>` +
        field("f_init", "Initial deposit", "number") };
    case 3: return { title: "Deposit", button: "Deposit", html: field("f_acc", "Account No", "number") + field("f_amt", "Amount", "number") };
    case 4: return { title: "Withdraw", button: "Withdraw", html: field("f_acc", "Account No", "number") + field("f_amt", "Amount", "number") };
    case 5: return { title: "Transfer", button: "Transfer",
      html: `<div class="row">${field("f_from", "From A/C", "number")}${field("f_to", "To A/C", "number")}</div>` + field("f_amt", "Amount", "number") };
    case 6: return { title: "Inter-Bank Transfer", button: "Send",
      html: `<div class="row">
          <div class="field"><label for="f_srcBank">From bank</label><select id="f_srcBank">` +
            Object.values(banks).map(b => `<option value="${b.cfg.theme}"${b === cur ? " selected" : ""}>${esc(b.name)}</option>`).join("") +
          `</select></div>
          <div class="field"><label for="f_bank">To bank</label><select id="f_bank"></select></div>
        </div>
        <div class="row">${field("f_from", "From A/C", "number", "f_fromLabel")}${field("f_to", "To A/C", "number", "f_toLabel")}</div>` +
        field("f_amt", "Amount", "number") };
    case 7: return { title: "Statement", button: "Show Statement", html: field("f_acc", "Account No", "number") };
    case 10: return { title: "Delete", button: "Delete",
      html: `<div id="undoBox"></div>` +
        `<div class="field"><label for="f_mode">Delete what?</label><select id="f_mode">
          <option value="1">An account (by account no)</option>
          <option value="2">A customer's Savings account</option>
          <option value="3">A customer's Current account</option>
          <option value="4">A whole customer (with all accounts)</option></select></div>` +
        `<div class="field"><label for="f_id" id="f_idLabel">Account No</label><input id="f_id" type="number"></div>` };
  }
}

/* ----- actions ----- */
const ACTIONS = {
  1(){
    const n = $("f_name").value.trim();
    if (!n) throw new BankException("Name cannot be empty!");
    return ok("Customer created with ID " + cur.addCustomer(n).id);
  },
  2(){
    const c = cur.getCustomer(readInt("f_cid"));
    const k = $("f_kind").value;
    const init = readDouble("f_init");
    const a = cur.openAccount(c, k, init);
    return ok(`${a.type()} account ${a.accNo} opened for ${c.name}`);
  },
  3(){
    const a = cur.findAccount(readInt("f_acc"));
    a.deposit(readDouble("f_amt"));
    return ok("Deposited. New balance: " + money(a.balance));
  },
  4(){
    const a = cur.findAccount(readInt("f_acc"));
    a.withdraw(readDouble("f_amt"));
    return ok("Withdrawn. New balance: " + money(a.balance));
  },
  5(){
    const f = readInt("f_from"), t = readInt("f_to");
    cur.transfer(f, t, readDouble("f_amt"));
    return ok("Transfer successful.");
  },
  6(){
    const f = readInt("f_from"), t = readInt("f_to"), amt = readDouble("f_amt");
    const dst = banks[$("f_bank").value], src = banks[$("f_srcBank").value];
    if (src === dst) throw new BankException("Choose two different banks.");
    interBankTransfer(src, f, dst, t, amt);
    return ok(`Transfer successful: ${money(amt)} sent from ${src.name} A/C ${f} to ${dst.name} A/C ${t}.`) +
      info(`New balance of A/C ${f}: <b>${money(src.findAccount(f).balance)}</b>`);
  },
  7(){
    const no = readInt("f_acc");
    const acc = cur.findAccount(no);
    const owner = cur.customers.find(c => c.findAccount(no));
    stmt = { bank: cur, acc, owner: owner.name, filter: "all" };
    return statementHtml();
  },
  10(){
    const k = $("f_mode").value, id = readInt("f_id");
    const what = { 1: "account " + id,
                   2: "all Savings accounts of customer " + id,
                   3: "all Current accounts of customer " + id,
                   4: "customer " + id + " and all their accounts" }[k];
    if (!confirm("Delete " + what + "?\nThis cannot be undone from the menu, only with the Undo button.")) throw new BankException("Delete cancelled.");
    let rec, msg;
    if (k === "1"){ rec = cur.deleteAccount(id); msg = "Account " + id + " deleted."; }
    else if (k === "4"){ rec = cur.deleteCustomer(id); msg = "Customer " + id + " deleted."; }
    else {
      const type = k === "2" ? "Savings" : "Current";
      rec = cur.deleteAccountsByType(id, type);
      msg = rec.removed.length + " " + type + " account(s) deleted.";
    }
    lastDelete = { bank: cur, rec, text: what };
    return ok(msg);
  }
};

/* ----- menu handling ----- */
function select(n){
  document.querySelectorAll(".menu-btn").forEach(b => b.classList.toggle("active", String(b.dataset.act) === String(n)));
}
function resetView(){
  select(null);
  $("formTitle").textContent = "Welcome";
  $("formArea").innerHTML = `<p class="hint">Choose an option from the menu to begin.</p>`;
  $("output").innerHTML = `<p class="hint">Results will appear here.</p>`;
}

async function runMenu(n){
  n = Number(n);
  select(n);
  try {
    if (n === 8){
      $("formTitle").textContent = "View All Accounts";
      $("formArea").innerHTML = `<p class="hint">Showing every customer and account of ${esc(cur.name)}.</p>`;
      show(`<input id="searchBox" class="search" type="search" placeholder="&#128269; Search by customer name or account number" autocomplete="off">` +
           `<div id="accTable">${accountsTable()}</div>`);
      return;
    }
    if (n === 9){
      $("formTitle").textContent = "Save Data Now";
      $("formArea").innerHTML = `<p class="hint">Writes all data to ${esc(cur.cfg.key)}.</p>`;
      await saveBank(cur);
      show(ok("Data saved to " + cur.cfg.key + (cur.handle ? "" : " (browser storage)")));
      return;
    }
    if (n === 0){
      $("formTitle").textContent = "Exit";
      $("formArea").innerHTML = `<p class="hint">Your data is saved automatically.</p>`;
      show(`<div class="alert ok">Thank you for banking with us. Goodbye!</div>`);
      return;
    }
    const form = getForm(n);
    $("formTitle").textContent = form.title;
    $("formArea").innerHTML = `<form id="theForm">${form.html}<button class="go${n === 10 ? " danger" : ""}" type="submit">${form.button}</button></form>`;
    $("theForm").addEventListener("submit", e => { e.preventDefault(); submitForm(n); });
    if (n === 10){
      refreshUndoBox();
      $("f_mode").addEventListener("change", e =>
        $("f_idLabel").textContent = e.target.value === "1" ? "Account No" : "Customer ID");
    }
    if (n === 6){                                       // any bank -> any other bank
      const sync = () => {
        const srcKey = $("f_srcBank").value, prev = $("f_bank").value;
        $("f_bank").innerHTML = Object.values(banks).filter(b => b.cfg.theme !== srcKey)
          .map(b => `<option value="${b.cfg.theme}">${esc(b.name)}</option>`).join("");
        if (prev && prev !== srcKey) $("f_bank").value = prev;
        const s = banks[srcKey], d = banks[$("f_bank").value];
        $("f_fromLabel").textContent = "From A/C (" + s.name + ")";
        $("f_toLabel").textContent = "To A/C (" + d.name + ")";
        $("theForm").querySelector(".go").textContent = "Send to " + d.name;
      };
      $("f_srcBank").addEventListener("change", sync);
      $("f_bank").addEventListener("change", sync);
      sync();
    }
    const first = $("formArea").querySelector("input,select"); if (first) first.focus();
  } catch (e){
    show(err(errText(e)));
  }
}

async function submitForm(n){
  let html;
  try {
    const dst = n === 6 ? banks[$("f_bank").value] : null;
    const src6 = n === 6 ? banks[$("f_srcBank").value] : null;
    html = ACTIONS[n]();
    if ((n >= 1 && n <= 5) || n === 10){                // auto-save, same as main.cpp
      await saveBank(cur);
      html += info("&#128190; Data saved to " + esc(cur.cfg.key));
    } else if (n === 6){                                // both banks changed
      await saveBank(src6); await saveBank(dst);
      html += info("&#128190; Data saved to " + esc(src6.cfg.key) + " and " + esc(dst.cfg.key));
    }
    if (n === 10) refreshUndoBox();
    $("formArea").querySelectorAll("input").forEach(i => i.value = "");
    const first = $("formArea").querySelector("input"); if (first) first.focus();
  } catch (e){
    html = err(errText(e));
  }
  show(html);
  banner();
}

document.querySelectorAll(".menu-btn").forEach(b => b.addEventListener("click", () => runMenu(b.dataset.act).then(banner)));

/* ----- Monthly Update: interest preview first, then apply (button in the top-right corner) ----- */
function runMonthly(){
  select(null);
  $("formTitle").textContent = "Monthly Update";
  $("formArea").innerHTML = `<p class="hint">Preview for ${esc(cur.name)}: interest is added to Savings accounts and the fee is deducted from Current accounts.</p>`;
  const rows = cur.previewMonthlyUpdate();
  if (!rows.length){ show(info("No accounts to update.")); return; }
  const total = rows.reduce((s, r) => s + r.change, 0);
  const sign = v => (v >= 0 ? "+" : "") + money(v);
  show(`<div class="sub">Interest preview &mdash; nothing is changed yet</div>
    <div class="table-wrap"><table>
      <tr><th>A/C No</th><th>Customer</th><th>Type</th><th class="num">Balance now</th><th class="num">Change</th><th class="num">Balance after</th></tr>` +
    rows.map(r => `<tr><td>${r.accNo}</td><td>${esc(r.customer)}</td><td><span class="tag ${r.type}">${r.type}</span></td>
        <td class="num">${money(r.balance)}</td><td class="num ${r.change >= 0 ? "pos" : "neg"}">${sign(r.change)}</td>
        <td class="num">${money(r.balance + r.change)}</td></tr>`).join("") +
    `<tr class="total"><td colspan="4">Total change</td><td class="num ${total >= 0 ? "pos" : "neg"}">${sign(total)}</td><td></td></tr>
    </table></div>
    <div class="btn-row">
      <button type="button" class="go" data-apply>Apply Monthly Update</button>
      <button type="button" class="go secondary" data-cancel>Cancel</button>
    </div>`);
}
async function applyMonthly(){
  try {
    const lines = cur.applyMonthlyUpdate();
    let html = ok("Monthly update applied.") + lines.map(l =>
      info(`A/C ${l.accNo} (${l.type}): <b>${l.amount >= 0 ? "+" : ""}${money(l.amount)}</b>`)).join("");
    await saveBank(cur);
    html += info("&#128190; Data saved to " + esc(cur.cfg.key));
    show(html);
  } catch (e){ show(err(errText(e))); }
  banner();
}
$("monthlyBtn").addEventListener("click", runMonthly);

/* ----- clicks inside the output / form area (filters, print, undo, apply...) ----- */
document.addEventListener("click", e => {
  const t = e.target.closest("[data-undo],[data-filter],[data-print],[data-csv],[data-apply],[data-cancel]");
  if (!t) return;
  if (t.hasAttribute("data-undo")) undoDelete();
  else if (t.hasAttribute("data-apply")) applyMonthly();
  else if (t.hasAttribute("data-cancel")) show(info("Monthly update cancelled."));
  else if (stmt){
    if (t.hasAttribute("data-filter")){ stmt.filter = t.dataset.filter; show(statementHtml()); }
    else if (t.hasAttribute("data-print")) printStatement();
    else if (t.hasAttribute("data-csv")) downloadStatement();
  }
});
document.addEventListener("input", e => {                // live search in View All Accounts
  if (e.target.id === "searchBox") $("accTable").innerHTML = accountsTable(e.target.value);
});

/* ----- switch bank (coloured dropdown) ----- */
const bankBtn = $("bankBtn"), bankList = $("bankList");
bankList.innerHTML = Object.values(banks).map(b => {
  const [c1, c2, c3] = PALETTE[b.cfg.theme];
  return `<button type="button" class="bank-opt" role="option" data-bank="${b.cfg.theme}" style="--b1:${c1};--b2:${c2};--ac:${c3}">
    ${swatch(b.cfg.theme)}<span class="nm">${esc(b.name)}</span><span class="tick">&#10004;</span></button>`;
}).join("");

function toggleBankList(open){
  bankList.hidden = !open;
  bankBtn.setAttribute("aria-expanded", String(open));
}
bankBtn.addEventListener("click", () => toggleBankList(bankList.hidden));
document.addEventListener("click", e => { if (!e.target.closest(".bank-dd")) toggleBankList(false); });
document.addEventListener("keydown", e => { if (e.key === "Escape") toggleBankList(false); });

bankList.addEventListener("click", e => {
  const opt = e.target.closest(".bank-opt");
  if (!opt) return;
  toggleBankList(false);
  if (banks[opt.dataset.bank] === cur) return;
  cur = banks[opt.dataset.bank];
  resetView();
  banner();
  welcome();
  toast("Switched to " + cur.name, "info");
});

/* ----- link the real txt file of the current bank (Chrome / Edge) ----- */
$("linkBtn").addEventListener("click", async () => {
  const bank = cur;
  if (!window.showOpenFilePicker){
    downloadBank(bank);
    toast("This browser can't link files. " + bank.cfg.key + " was downloaded instead.", "info");
    return;
  }
  try {
    const [h] = await showOpenFilePicker({ types: [{ description: "Text file", accept: { "text/plain": [".txt"] } }] });
    const text = await (await h.getFile()).text();
    bank.load(text.trim() ? text : bank.cfg.defaultData);
    bank.handle = h;
    await saveBank(bank);
    banner();
    show(ok("Linked to " + bank.cfg.key + " - all changes of " + bank.name + " are now saved in that file."));
  } catch (e){
    if (e.name !== "AbortError") show(err(errText(e)));
  }
});

banner();
welcome();
