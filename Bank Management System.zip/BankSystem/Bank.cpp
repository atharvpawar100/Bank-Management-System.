// 7. Bank.cpp - top-level manager that ties everything together
#pragma once
#include "Customer.cpp"

class Bank {
    std::string name;
    std::vector<Customer> customers;
public:
    explicit Bank(const std::string& n) : name(n) {}

    Customer& addCustomer(const std::string& custName) {
        customers.emplace_back(custName);
        return customers.back();
    }
    Customer& restoreCustomer(int id, const std::string& custName) {   // for loading
        customers.emplace_back(id, custName);
        return customers.back();
    }
    Customer& getCustomer(int id) {
        for (auto& c : customers) if (c.getId() == id) return c;
        throw NotFoundException("Customer");
    }
    std::shared_ptr<Account> findAccount(int accNo) {
        for (auto& c : customers)
            if (auto a = c.findAccount(accNo)) return a;
        throw NotFoundException("Account");
    }
    // ---- delete support ----
    void deleteAccount(int accNo) {
        for (auto& c : customers)
            if (c.removeAccount(accNo)) return;
        throw NotFoundException("Account");
    }
    int deleteAccountsByType(int custId, const std::string& type) {
        int n = getCustomer(custId).removeAccountsByType(type);
        if (n == 0) throw BankException("This customer has no " + type + " account!");
        return n;
    }
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it)
            if (it->getId() == id) { customers.erase(it); return; }
        throw NotFoundException("Customer");
    }
    void transfer(int from, int to, double amt) {
        auto src = findAccount(from);
        auto dst = findAccount(to);
        src->withdraw(amt);      // throws if not allowed, so deposit never runs
        dst->deposit(amt);
    }
    void applyMonthlyUpdate() {
        for (auto& c : customers)
            for (const auto& a : c.getAccounts()) {
                double r = a->monthlyUpdate();            // polymorphic call
                std::cout << "A/C " << a->getAccNo() << " (" << a->type() << "): "
                          << (r >= 0 ? "+" : "") << r << "\n";
            }
    }
    // helpers used by the UI dashboard
    const std::vector<Customer>& getCustomers() const { return customers; }
    const std::string& getName() const { return name; }
    double totalDeposits() const {
        double sum = 0;
        for (const auto& c : customers) sum += c.totalBalance();
        return sum;
    }
    void showAll() const {
        std::cout << "\n===== " << name << " =====\n";
        for (const auto& c : customers) c.display();
        std::cout << "\nTotal accounts: " << Account::getTotalAccounts() << "\n";
    }
};
