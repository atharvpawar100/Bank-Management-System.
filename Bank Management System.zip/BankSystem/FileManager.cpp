// 9. FileManager.cpp - saves / loads the whole bank to a plain text file
#pragma once
#include "Bank.cpp"
#include <fstream>
#include <sstream>
#include <algorithm>

/*  File format (bank_data.txt), one record per line, fields separated by '|'
      NEXT_CUSTOMER_ID|3
      NEXT_ACCOUNT_NO|1003
      CUSTOMER|id|name
      ACCOUNT|accNo|S or C|balance           <- belongs to the CUSTOMER above
      TXN|time|type|amount|balanceAfter      <- belongs to the ACCOUNT above
*/
class FileManager {
    std::string filename;

    static std::string clean(std::string s) {          // keep '|' out of names
        for (char& c : s) if (c == '|' || c == '\n' || c == '\r') c = '_';
        return s;
    }
    static std::vector<std::string> split(const std::string& line) {
        std::vector<std::string> parts;
        std::stringstream ss(line);
        std::string item;
        while (std::getline(ss, item, '|')) parts.push_back(item);
        return parts;
    }
public:
    explicit FileManager(const std::string& file = "bank_data.txt") : filename(file) {}

    void save(const Bank& bank) const {
        std::ofstream out(filename);
        if (!out) throw BankException("Cannot write to file " + filename);

        out << "# OOP National Bank data file - edit with care\n";
        out << "NEXT_CUSTOMER_ID|" << Customer::getNextId() << "\n";
        out << "NEXT_ACCOUNT_NO|" << Account::getNextAccNo() << "\n";
        out << std::fixed << std::setprecision(2);

        for (const auto& c : bank.getCustomers()) {
            out << "CUSTOMER|" << c.getId() << "|" << clean(c.getName()) << "\n";
            for (const auto& a : c.getAccounts()) {
                out << "ACCOUNT|" << a->getAccNo() << "|"
                    << (a->type() == "Savings" ? 'S' : 'C') << "|" << a->getBalance() << "\n";
                for (const auto& t : a->getHistory())
                    out << "TXN|" << t.getTime() << "|" << t.getType() << "|"
                        << t.getAmount() << "|" << t.getBalanceAfter() << "\n";
            }
        }
        if (!out) throw BankException("Error while writing " + filename);
    }

    // returns false if there is no file yet (first run)
    bool load(Bank& bank) const {
        std::ifstream in(filename);
        if (!in) return false;

        Customer* cust = nullptr;
        std::shared_ptr<Account> acc;
        int nextCust = 1, nextAcc = 1001, maxCust = 0, maxAcc = 1000;
        std::string line;

        try {
            while (std::getline(in, line)) {
                if (!line.empty() && line.back() == '\r') line.pop_back();   // Windows files
                if (line.empty() || line[0] == '#') continue;

                auto f = split(line);
                const std::string& tag = f.at(0);

                if (tag == "NEXT_CUSTOMER_ID")      nextCust = std::stoi(f.at(1));
                else if (tag == "NEXT_ACCOUNT_NO")  nextAcc  = std::stoi(f.at(1));
                else if (tag == "CUSTOMER") {
                    int id = std::stoi(f.at(1));
                    cust = &bank.restoreCustomer(id, f.at(2));
                    acc = nullptr;
                    maxCust = std::max(maxCust, id);
                } else if (tag == "ACCOUNT") {
                    if (!cust) throw BankException("ACCOUNT before CUSTOMER");
                    int no = std::stoi(f.at(1));
                    acc = cust->openAccount(f.at(2).at(0), 0);      // polymorphic factory
                    acc->restoreState(no, std::stod(f.at(3)));
                    maxAcc = std::max(maxAcc, no);
                } else if (tag == "TXN") {
                    if (!acc) throw BankException("TXN before ACCOUNT");
                    acc->addHistory(Transaction(f.at(2), std::stod(f.at(3)),
                                                std::stod(f.at(4)), f.at(1)));
                }
            }
        } catch (const BankException&) {
            throw;
        } catch (const std::exception&) {
            throw BankException("Data file '" + filename + "' is corrupted (bad line: " + line + ")");
        }
        Customer::setNextId(std::max(nextCust, maxCust + 1));
        Account::setNextAccNo(std::max(nextAcc, maxAcc + 1));
        return true;
    }
};
