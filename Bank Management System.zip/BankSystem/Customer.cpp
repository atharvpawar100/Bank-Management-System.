// 6. Customer.cpp - composition: a Customer HAS many Accounts (smart pointers + polymorphism)
#pragma once
#include "SavingsAccount.cpp"
#include "CurrentAccount.cpp"
#include <memory>

class Customer {
    static int nextId;
    int id;
    std::string name;
    std::vector<std::shared_ptr<Account>> accounts;   // base-class pointers
public:
    explicit Customer(const std::string& n) : id(nextId++), name(n) {}
    Customer(int existingId, const std::string& n) : id(existingId), name(n) {}  // for loading
    static void setNextId(int n) { nextId = n; }
    static int getNextId() { return nextId; }

    // Factory-style: returns base pointer to different derived objects
    std::shared_ptr<Account> openAccount(char kind, double initial) {
        std::shared_ptr<Account> acc;
        if (kind == 's' || kind == 'S') acc = std::make_shared<SavingsAccount>(initial);
        else                            acc = std::make_shared<CurrentAccount>(initial);
        accounts.push_back(acc);
        return acc;
    }
    std::shared_ptr<Account> findAccount(int accNo) const {
        for (const auto& a : accounts) if (a->getAccNo() == accNo) return a;
        return nullptr;
    }
    // ---- delete support ----
    bool removeAccount(int accNo) {
        for (auto it = accounts.begin(); it != accounts.end(); ++it)
            if ((*it)->getAccNo() == accNo) { accounts.erase(it); return true; }
        return false;
    }
    int removeAccountsByType(const std::string& t) {   // returns how many were removed
        int n = 0;
        for (auto it = accounts.begin(); it != accounts.end(); ) {
            if ((*it)->type() == t) { it = accounts.erase(it); n++; }
            else ++it;
        }
        return n;
    }
    double totalBalance() const {
        double sum = 0;
        for (const auto& a : accounts) sum += a->getBalance();
        return sum;
    }
    void display() const {
        std::cout << "\nCustomer #" << id << ": " << name << "\n";
        for (const auto& a : accounts) a->display();   // runtime polymorphism
    }
    int getId() const { return id; }
    const std::string& getName() const { return name; }
    const std::vector<std::shared_ptr<Account>>& getAccounts() const { return accounts; }
};
int Customer::nextId = 1;
