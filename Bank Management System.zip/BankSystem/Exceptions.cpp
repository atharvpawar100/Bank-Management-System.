// 1. Exceptions.cpp - custom exception hierarchy (inheritance)
#pragma once
#include <stdexcept>
#include <string>

class BankException : public std::runtime_error {
public:
    explicit BankException(const std::string& msg) : std::runtime_error(msg) {}
};

class InsufficientFundsException : public BankException {
public:
    InsufficientFundsException() : BankException("Insufficient funds / limit exceeded!") {}
};

class InvalidAmountException : public BankException {
public:
    InvalidAmountException() : BankException("Amount must be greater than zero!") {}
};

class NotFoundException : public BankException {
public:
    explicit NotFoundException(const std::string& what) : BankException(what + " not found!") {}
};
