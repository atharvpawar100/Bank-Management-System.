// 5. CurrentAccount.cpp - derived class #2 (overdraft, monthly fee)
#pragma once
#include "Account.cpp"

class CurrentAccount : public Account {
    static constexpr double OVERDRAFT = 5000.0;
    static constexpr double FEE = 100.0;
public:
    explicit CurrentAccount(double initial) : Account(initial) {}

    void withdraw(double amt) override {
        if (amt <= 0) throw InvalidAmountException();
        if (balance - amt < -OVERDRAFT) throw InsufficientFundsException();
        balance -= amt;
        record("Withdraw", amt);
    }
    double monthlyUpdate() override {          // deducts maintenance fee
        balance -= FEE;
        record("Maintenance Fee", FEE);
        return -FEE;
    }
    std::string type() const override { return "Current"; }
    void display() const override {            // extended override
        Account::display();
        std::cout << "      Overdraft limit: " << OVERDRAFT << "\n";
    }
};
