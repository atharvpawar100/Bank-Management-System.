// 8. main.cpp - ConsoleUI class: colourful menu-driven interface
// Build:  g++ -std=c++17 main.cpp -o bank
#include "FileManager.cpp"
#include <cstdlib>
#include <sstream>
#ifdef _WIN32
#include <windows.h>
#endif

namespace Col {
    constexpr const char* RESET  = "\033[0m";
    constexpr const char* BOLD   = "\033[1m";
    constexpr const char* RED    = "\033[31m";
    constexpr const char* GREEN  = "\033[32m";
    constexpr const char* YELLOW = "\033[33m";
    constexpr const char* BLUE   = "\033[34m";
    constexpr const char* CYAN   = "\033[36m";
}

class ConsoleUI {
    Bank& bank;
    FileManager& fm;
    static const int W = 58;

    // ---------- small helpers ----------
    void clear() const { std::cout << "\033[2J\033[H"; }
    void line(char c = '=') const { std::cout << Col::BLUE << '+' << std::string(W, c) << '+' << Col::RESET << "\n"; }
    void row(const std::string& text, const char* color = Col::RESET) const {
        std::cout << Col::BLUE << "| " << Col::RESET << color << std::left << std::setw(W - 2) << text
                  << Col::RESET << Col::BLUE << " |" << Col::RESET << "\n";
    }
    static std::string money(double v) {
        std::ostringstream os; os << std::fixed << std::setprecision(2) << v; return os.str();
    }
    void ok(const std::string& m)  const { std::cout << Col::GREEN << "\n  [OK] "    << m << Col::RESET << "\n"; }
    void err(const std::string& m) const { std::cout << Col::RED   << "\n  [ERROR] " << m << Col::RESET << "\n"; }

    std::string readLine(const std::string& prompt) const {
        std::cout << Col::CYAN << "  " << prompt << Col::RESET;
        std::string s;
        if (!std::getline(std::cin, s)) { std::cout << "\n"; std::exit(0); }
        return s;
    }
    int readInt(const std::string& prompt) const {
        while (true) {
            std::string s = readLine(prompt);
            try { size_t pos; int v = std::stoi(s, &pos); if (pos == s.size()) return v; } catch (...) {}
            err("Please enter a valid whole number.");
        }
    }
    double readDouble(const std::string& prompt) const {
        while (true) {
            std::string s = readLine(prompt);
            try { size_t pos; double v = std::stod(s, &pos); if (pos == s.size()) return v; } catch (...) {}
            err("Please enter a valid amount.");
        }
    }
    void pause() const { readLine("\n  Press Enter to continue..."); }

    // ---------- screens ----------
    void banner() const {
        clear();
        line();
        row("        " + bank.getName() + "  -  BANK MANAGEMENT", Col::BOLD);
        line();
        std::ostringstream os;
        os << "Customers: " << bank.getCustomers().size()
           << "   Accounts: " << Account::getTotalAccounts()
           << "   Deposits: " << std::fixed << std::setprecision(2) << bank.totalDeposits();
        row(os.str(), Col::YELLOW);
        line('-');
    }
    void menu() const {
        row("1. New Customer          5. Transfer");
        row("2. Open Account          6. Statement");
        row("3. Deposit               7. Monthly Update");
        row("4. Withdraw              8. View All Accounts");
        row("9. Save Data Now         10. Delete");
        row("0. Exit", Col::RED);
        line();
    }
    void accountsTable() const {
        std::cout << Col::BOLD << "\n  " << std::left << std::setw(6) << "ID" << std::setw(16) << "Customer"
                  << std::setw(9) << "A/C No" << std::setw(10) << "Type" << std::right << std::setw(12)
                  << "Balance" << Col::RESET << "\n  " << std::string(53, '-') << "\n";
        for (const auto& c : bank.getCustomers()) {
            if (c.getAccounts().empty())
                std::cout << "  " << std::left << std::setw(6) << c.getId() << std::setw(16) << c.getName()
                          << "(no accounts)\n";
            for (const auto& a : c.getAccounts()) {
                std::cout << "  " << std::left << std::setw(6) << c.getId() << std::setw(16) << c.getName()
                          << std::setw(9) << a->getAccNo() << std::setw(10) << a->type()
                          << (a->getBalance() < 0 ? Col::RED : Col::GREEN) << std::right << std::setw(12)
                          << std::fixed << std::setprecision(2) << a->getBalance() << Col::RESET << "\n";
            }
        }
    }

    // ---------- actions ----------
    void newCustomer() {
        std::string n = readLine("Customer name: ");
        if (n.empty()) throw BankException("Name cannot be empty!");
        ok("Customer created with ID " + std::to_string(bank.addCustomer(n).getId()));
    }
    void openAccount() {
        Customer& c = bank.getCustomer(readInt("Customer ID: "));
        std::string k = readLine("Type (s = Savings, c = Current): ");
        double init = readDouble("Initial deposit: ");
        auto a = c.openAccount(k.empty() ? 's' : k[0], init);
        ok(a->type() + " account " + std::to_string(a->getAccNo()) + " opened for " + c.getName());
    }
    void deposit() {
        auto a = bank.findAccount(readInt("Account No: "));
        *a += readDouble("Amount: ");                    // operator+=
        ok("Deposited. New balance: " + money(a->getBalance()));
    }
    void withdraw() {
        auto a = bank.findAccount(readInt("Account No: "));
        a->withdraw(readDouble("Amount: "));
        ok("Withdrawn. New balance: " + money(a->getBalance()));
    }
    void transfer() {
        int f = readInt("From A/C: "), t = readInt("To A/C: ");
        bank.transfer(f, t, readDouble("Amount: "));
        ok("Transfer successful.");
    }
    void deleteMenu() {
        std::cout << "\n  Delete what?\n"
                  << "    1. An account (by account no)\n"
                  << "    2. A customer's Savings account\n"
                  << "    3. A customer's Current account\n"
                  << "    4. A whole customer (with all accounts)\n";
        int k = readInt("Choose 1-4: ");
        if (k < 1 || k > 4) throw BankException("Invalid delete option.");

        int id = readInt(k == 1 ? "Account No: " : "Customer ID: ");
        std::string what = (k == 1) ? "account " + std::to_string(id)
                         : (k == 2) ? "all Savings accounts of customer " + std::to_string(id)
                         : (k == 3) ? "all Current accounts of customer " + std::to_string(id)
                                    : "customer " + std::to_string(id) + " and all accounts";
        std::string sure = readLine("Delete " + what + "? (y/n): ");
        if (sure.empty() || (sure[0] != 'y' && sure[0] != 'Y')) throw BankException("Delete cancelled.");

        if (k == 1)      { bank.deleteAccount(id);                         ok("Account " + std::to_string(id) + " deleted."); }
        else if (k == 2) { int n = bank.deleteAccountsByType(id, "Savings"); ok(std::to_string(n) + " Savings account(s) deleted."); }
        else if (k == 3) { int n = bank.deleteAccountsByType(id, "Current"); ok(std::to_string(n) + " Current account(s) deleted."); }
        else             { bank.deleteCustomer(id);                        ok("Customer " + std::to_string(id) + " deleted."); }
    }
    void statement() {
        std::cout << "\n";
        bank.findAccount(readInt("Account No: "))->printStatement();
    }
public:
    ConsoleUI(Bank& b, FileManager& f) : bank(b), fm(f) {
#ifdef _WIN32   // enable ANSI colours on Windows 10+
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE); DWORD m = 0;
        GetConsoleMode(h, &m); SetConsoleMode(h, m | 0x0004);
#endif
    }
    void run() {
        int choice = -1;
        while (choice != 0) {
            banner();
            menu();
            choice = readInt("Choose option: ");
            try {
                switch (choice) {
                    case 1: newCustomer(); break;
                    case 2: openAccount(); break;
                    case 3: deposit();     break;
                    case 4: withdraw();    break;
                    case 5: transfer();    break;
                    case 6: statement();   break;
                    case 7: std::cout << "\n"; bank.applyMonthlyUpdate(); break;
                    case 8: accountsTable(); break;
                    case 9: fm.save(bank); ok("Data saved to bank_data.txt"); break;
                    case 10: deleteMenu(); break;
                    case 0: continue;
                    default: err("Invalid option.");
                }
                if ((choice >= 1 && choice <= 5) || choice == 7 || choice == 10) fm.save(bank);   // auto-save
            } catch (const BankException& e) { err(e.what()); }
            if (choice != 0) pause();
        }
        std::cout << Col::GREEN << "\n  Thank you for banking with us. Goodbye!\n" << Col::RESET;
    }
};

int main() {
    Bank bank("OOP NATIONAL BANK");
    FileManager fm("bank_data.txt");
    try {
        fm.load(bank);                       // restore previous records (if any)
    } catch (const BankException& e) {
        std::cout << "Could not load data: " << e.what() << "\n";
        return 1;                            // stop, so a bad file is never overwritten
    }
    ConsoleUI ui(bank, fm);
    ui.run();
}
